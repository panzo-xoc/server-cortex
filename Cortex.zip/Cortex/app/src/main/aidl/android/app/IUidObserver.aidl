// Letak package harus persis android.app
package android.app;

/**
 * Hidden API Android untuk memantau perubahan status UID.
 * Metode di bawah ini mencakup kompatibilitas dari Android 8 (Oreo) hingga Android 14.
 */
interface IUidObserver {

    // Dipanggil saat UID tidak lagi memiliki proses yang berjalan
    void onUidGone(int uid, boolean disabled);

    // Dipanggil saat UID menjadi aktif
    void onUidActive(int uid);

    // Dipanggil saat UID menjadi idle (menganggur)
    void onUidIdle(int uid, boolean disabled);

    // Dipanggil saat status proses dari UID berubah (Android 11+)
    void onUidStateChanged(int uid, int procState, long procStateSeq, int capability);

    // Dipanggil saat status cache UID berubah
    void onUidCachedChanged(int uid, boolean cached);

    // Beberapa versi Android (seperti Android 13/14) mungkin membutuhkan ini
    void onUidProcAdjChanged(int uid);
}

