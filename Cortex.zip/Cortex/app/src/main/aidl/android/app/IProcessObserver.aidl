// Letak package harus persis android.app
package android.app;

/**
 * Hidden API Android untuk memantau perubahan status proses aplikasi.
 */
interface IProcessObserver {

    // Dipanggil ketika status aplikasi (foreground/background) berubah
    void onForegroundActivitiesChanged(int pid, int uid, boolean foregroundActivities);

    // Dipanggil ketika ada perubahan pada Foreground Service
    void onForegroundServicesChanged(int pid, int uid, int serviceTypes);

    // Dipanggil ketika sebuah proses mati (ter-kill/force close)
    void onProcessDied(int pid, int uid);
}

