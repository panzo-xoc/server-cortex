package pzo.cortex;

// Ini adalah antarmuka komunikasi antara APK dan Server
interface ICortexInterface {
    
    // Contoh 1: Fungsi untuk mengecek apakah server merespons
    boolean ping();

    // Contoh 2: Fungsi untuk mengeksekusi perintah shell/root
    String execCommand(String command);

    // Tambahkan fungsi lain sesuai kebutuhan Anda di sini...
}

