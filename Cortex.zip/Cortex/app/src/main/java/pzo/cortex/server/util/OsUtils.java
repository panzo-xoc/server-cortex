package pzo.cortex.server.util;



import android.annotation.SuppressLint;
import android.system.Os;
import java.lang.reflect.Method;

public class OsUtils {
    private static final int PID = Os.getpid();
    private static final int UID = Os.getuid();
    private static final String SELINUX_CONTEXT = getSELinuxContextViaReflection();

    public static int getPid() {
        return PID;
    }

    public static int getUid() {
        return UID;
    }

    public static String getSELinuxContext() {
        return SELINUX_CONTEXT;
    }

    public static boolean isRoot() {
        return UID == 0;
    }

    // Menggunakan Reflection untuk menghindari error Hidden API / Missing class di AIDE
    private static String getSELinuxContextViaReflection() {
        try {
            @SuppressLint("PrivateApi")
				Class<?> selinuxClass = Class.forName("android.os.SELinux");
            Method getContextMethod = selinuxClass.getMethod("getContext");
            return (String) getContextMethod.invoke(null);
        } catch (Throwable e) {
            return null;
        }
    }
}

