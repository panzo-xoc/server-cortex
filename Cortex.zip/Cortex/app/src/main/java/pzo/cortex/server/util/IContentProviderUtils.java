package pzo.cortex.server.util;

import android.os.Bundle;
import java.lang.reflect.Method;

public class IContentProviderUtils {

    // Menggunakan Object untuk menggantikan IContentProvider agar aman dari Hidden API & Missing Class
    public static Bundle callCompat(Object iContentProvider, String authority, String method, String arg, Bundle bundle) {
        try {
            if (iContentProvider == null) return null;

            // Cari method 'call' secara reflection di dalam objek iContentProvider
            Method callMethod = null;
            for (Method m : iContentProvider.getClass().getDeclaredMethods()) {
                if (m.getName().equals("call")) {
                    callMethod = m;
                    break;
                }
            }

            if (callMethod != null) {
                callMethod.setAccessible(true);

                // Parameter 'call' di IContentProvider berbeda-beda tiap versi Android
                Class<?>[] pTypes = callMethod.getParameterTypes();
                if (pTypes.length >= 5) {
                    // Untuk Android versi baru (Android 12+)
                    return (Bundle) callMethod.invoke(iContentProvider, authority, null, method, arg, bundle);
                } else {
                    // Untuk Android versi lama
                    return (Bundle) callMethod.invoke(iContentProvider, authority, method, arg, bundle);
                }
            }
        } catch (Throwable ignored) {}

        return null;
    }
}

