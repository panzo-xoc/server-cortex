package pzo.cortex.server;

import android.annotation.SuppressLint;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.text.TextUtils;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.lang.reflect.Field;

import android.app.IProcessObserver;
import android.app.IUidObserver;
import pzo.cortex.ICortexInterface;

public class BinderSender {

    private static final String TAG = "CortexBinderSender";

    private static final String PERMISSION_MANAGER = "pzo.cortex.manager.permission.MANAGER";

    private static final int UID_OBSERVER_GONE = 1 << 1;
    private static final int UID_OBSERVER_IDLE = 1 << 2;
    private static final int UID_OBSERVER_ACTIVE = 1 << 3;
    private static final int UID_OBSERVER_CACHED = 1 << 4;
    private static final int PROCESS_STATE_UNKNOWN = -1;

    private static ICortexInterface sBinder;

    private static Object sIActivityManager;
    private static Object sIPackageManager;

    static {
        try {
            @SuppressLint("PrivateApi")
				Class<?> activityManagerNative = Class.forName("android.app.ActivityManagerNative");
            sIActivityManager = activityManagerNative.getMethod("getDefault").invoke(null);

            @SuppressLint("PrivateApi")
				Class<?> activityThread = Class.forName("android.app.ActivityThread");
            sIPackageManager = activityThread.getMethod("getPackageManager").invoke(null);
        } catch (Throwable e) {
            Log.e(TAG, "Gagal menginisialisasi System Services", e);
        }
    }

    private static void sendBinder(int uid, int pid) {
        if (sIPackageManager == null || sIActivityManager == null) return;

        try {
            Method getPackagesForUid = sIPackageManager.getClass().getMethod("getPackagesForUid", int.class);
            String[] packagesArray = (String[]) getPackagesForUid.invoke(sIPackageManager, uid);

            if (packagesArray == null || packagesArray.length == 0) return;

            List<String> packagesList = Arrays.asList(packagesArray);
            Log.d(TAG, String.format("sendBinder to uid %d: packages=%s", uid, TextUtils.join(", ", packagesList)));

            int userId = uid / 100000;

            for (String packageName : packagesList) {
                Method getPackageInfo = sIPackageManager.getClass().getMethod("getPackageInfo", String.class, int.class, int.class);
                PackageInfo packageInfo = (PackageInfo) getPackageInfo.invoke(sIPackageManager, packageName, PackageManager.GET_PERMISSIONS, userId);

                if (packageInfo != null && packageInfo.requestedPermissions != null) {
                    List<String> requestedPerms = Arrays.asList(packageInfo.requestedPermissions);

                    if (requestedPerms.contains(PERMISSION_MANAGER)) {
                        boolean isGranted = false;

                        if (pid == -1) {
                            Method checkUidPermission = sIPackageManager.getClass().getMethod("checkUidPermission", String.class, int.class);
                            int result = (int) checkUidPermission.invoke(sIPackageManager, PERMISSION_MANAGER, uid);
                            isGranted = (result == PackageManager.PERMISSION_GRANTED);
                        } else {
                            Method checkPermission = sIActivityManager.getClass().getMethod("checkPermission", String.class, int.class, int.class);
                            int result = (int) checkPermission.invoke(sIActivityManager, PERMISSION_MANAGER, pid, uid);
                            isGranted = (result == PackageManager.PERMISSION_GRANTED);
                        }

                        if (isGranted) {
                            Log.i(TAG, "Aplikasi Cortex terdeteksi! Mengirim binder ke UID: " + uid);
                            sendBinderToManager(sBinder, userId, packageName);
                            return;
                        }
                    }
                }
            }
        } catch (Throwable th) {
            Log.e(TAG, "Error di sendBinder", th);
        }
    }

    public static void register(ICortexInterface binder) {
        sBinder = binder;

        if (sIActivityManager == null) {
            Log.e(TAG, "IActivityManager is null, Tidak dapat meregister observer");
            return;
        }

        try {
            Method registerProcessObserver = sIActivityManager.getClass().getMethod("registerProcessObserver", IProcessObserver.class);
            registerProcessObserver.invoke(sIActivityManager, new ProcessObserverImpl());
            Log.i(TAG, "ProcessObserver berhasil didaftarkan.");
        } catch (Throwable th) {
            Log.e(TAG, "registerProcessObserver gagal", th);
        }

        int flags = UID_OBSERVER_GONE | UID_OBSERVER_IDLE | UID_OBSERVER_ACTIVE | UID_OBSERVER_CACHED;

        try {
            Method registerUidObserver = sIActivityManager.getClass().getMethod("registerUidObserver", IUidObserver.class, int.class, int.class, String.class);
            registerUidObserver.invoke(sIActivityManager, new UidObserverImpl(), flags, PROCESS_STATE_UNKNOWN, null);
            Log.i(TAG, "UidObserver berhasil didaftarkan.");
        } catch (Throwable th2) {
            Log.e(TAG, "registerUidObserver gagal", th2);
        }
    }

    // [UPDATE] Mengirim Binder ke APK menggunakan ContentProvider.call() via Reflection
    private static void sendBinderToManager(ICortexInterface binder, int userId, String packageName) {
        try {
            // 1. Bungkus Binder
            BinderContainer container = new BinderContainer(binder);

            // 2. Masukkan ke dalam Bundle
            Bundle bundle = new Bundle();
            bundle.putParcelable("pzo.cortex.extra.BINDER", container);

            // 3. Authority sesuai dengan yang didaftarkan di AndroidManifest.xml APK utama
            String authority = packageName + ".provider";

            // 4. Ambil ContentProvider Holder dari ActivityManager secara external
            Method getContentProviderExternal = null;
            for (Method m : sIActivityManager.getClass().getDeclaredMethods()) {
                if (m.getName().equals("getContentProviderExternal")) {
                    getContentProviderExternal = m;
                    break;
                }
            }

            if (getContentProviderExternal != null) {
                getContentProviderExternal.setAccessible(true);
                Object holder = null;

                // Parameter getContentProviderExternal bisa berbeda tipenya di tiap versi Android
                Class<?>[] pTypes = getContentProviderExternal.getParameterTypes();
                if (pTypes.length == 4) {
                    holder = getContentProviderExternal.invoke(sIActivityManager, authority, userId, null, null);
                } else if (pTypes.length == 3) {
                    holder = getContentProviderExternal.invoke(sIActivityManager, authority, userId, null);
                }

                if (holder != null) {
                    // Dapatkan objek IContentProvider dari Holder
                    Field providerField = null;
                    try {
                        providerField = holder.getClass().getDeclaredField("provider");
                    } catch (NoSuchFieldException e) {
                        providerField = holder.getClass().getDeclaredField("mProvider");
                    }

                    if (providerField != null) {
                        providerField.setAccessible(true);
                        Object iContentProvider = providerField.get(holder);

                        if (iContentProvider != null) {
                            // Panggil method call() pada IContentProvider
                            Method callMethod = null;
                            for (Method m : iContentProvider.getClass().getDeclaredMethods()) {
                                if (m.getName().equals("call")) {
                                    callMethod = m;
                                    break;
                                }
                            }

                            if (callMethod != null) {
                                callMethod.setAccessible(true);
                                // Format parameter call: (String callingPkg, String method, String arg, Bundle extras) 
                                // atau variasi lainnya tergantung versi Android. Kita sesuaikan secara dinamis.
                                Object[] callArgs = new Object[callMethod.getParameterTypes().length];
                                Class<?>[] callParamTypes = callMethod.getParameterTypes();

                                for (int i = 0; i < callParamTypes.length; i++) {
                                    Class<?> t = callParamTypes[i];
                                    if (t == String.class) {
                                        if (callArgs[0] == null) {
                                            callArgs[i] = packageName; // callingPkg
                                        } else if (callArgs[1] == null) {
                                            callArgs[i] = "sendBinder"; // method name
                                        } else {
                                            callArgs[i] = null; // arg
                                        }
                                    } else if (Bundle.class.isAssignableFrom(t)) {
                                        callArgs[i] = bundle; // extras
                                    } else {
                                        callArgs[i] = null;
                                    }
                                }

                                callMethod.invoke(iContentProvider, callArgs);
                                Log.i(TAG, "Berhasil mengirim Binder ke ContentProvider APK: " + packageName);
                            }
                        }
                    }

                    // Lepas external provider agar tidak leak
                    try {
                        Method removeContentProviderExternal = sIActivityManager.getClass().getMethod("removeContentProviderExternal", String.class, IBinder.class);
                        removeContentProviderExternal.invoke(sIActivityManager, authority, null);
                    } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable e) {
            Log.e(TAG, "Gagal mengirim binder via ContentProvider", e);
        }
    }

    // --- INNER CLASSES UNTUK OBSERVER ---

    private static class ProcessObserverImpl extends IProcessObserver.Stub {
        private static final List<Integer> PID_LIST = new ArrayList<>();

        @Override
        public void onForegroundActivitiesChanged(int pid, int uid, boolean foregroundActivities) {
            synchronized (PID_LIST) {
                if (PID_LIST.contains(pid) || !foregroundActivities) return;
                PID_LIST.add(pid);
            }
            sendBinder(uid, pid);
        }

        @Override
        public void onForegroundServicesChanged(int pid, int uid, int serviceTypes) { }

        @Override
        public void onProcessDied(int pid, int uid) {
            synchronized (PID_LIST) {
                PID_LIST.remove(Integer.valueOf(pid));
            }
        }
    }

    private static class UidObserverImpl extends IUidObserver.Stub {
        private static final List<Integer> UID_LIST = new ArrayList<>();

        @Override
        public void onUidActive(int uid) {
            uidStarts(uid);
        }

        @Override
        public void onUidCachedChanged(int uid, boolean cached) {
            if (!cached) uidStarts(uid);
        }

        @Override
        public void onUidIdle(int uid, boolean disabled) {
            uidStarts(uid);
        }

        @Override
        public void onUidGone(int uid, boolean disabled) {
            synchronized (UID_LIST) {
                UID_LIST.remove(Integer.valueOf(uid));
            }
        }

        @Override
        public void onUidStateChanged(int uid, int procState, long procStateSeq, int capability) { }

        @Override
        public void onUidProcAdjChanged(int uid) { }

        private void uidStarts(int uid) {
            synchronized (UID_LIST) {
                if (UID_LIST.contains(uid)) return;
                UID_LIST.add(uid);
            }
            sendBinder(uid, -1);
        }
    }
}

