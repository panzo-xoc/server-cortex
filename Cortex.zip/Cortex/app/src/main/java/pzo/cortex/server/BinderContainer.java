package pzo.cortex.server;

import android.os.Parcel;
import android.os.Parcelable;

// Pastikan import ini sesuai dengan file AIDL Anda
import pzo.cortex.ICortexInterface;

public class BinderContainer implements Parcelable {

    public ICortexInterface binder;

    // Constructor biasa untuk membungkus Binder
    public BinderContainer(ICortexInterface binder) {
        this.binder = binder;
    }

    // Constructor untuk membuka bungkus dari Parcel
    protected BinderContainer(Parcel in) {
        this.binder = ICortexInterface.Stub.asInterface(in.readStrongBinder());
    }

    // Fungsi wajib Parcelable: Menyimpan data ke dalam "kardus"
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStrongBinder(this.binder != null ? this.binder.asBinder() : null);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    // Generator wajib dari Parcelable (diperbaiki agar AIDE tidak error)
    public static final Creator<BinderContainer> CREATOR = new Creator<BinderContainer>() {
        @Override
        public BinderContainer createFromParcel(Parcel in) {
            return new BinderContainer(in);
        }

        @Override
        public BinderContainer[] newArray(int size) {
            return new BinderContainer[size];
        }
    };
	}

