package pzo.cortex.server; // Sesuaikan package APK Anda

import android.annotation.SuppressLint;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;

// Import BinderContainer dan Interface Anda
import pzo.cortex.server.BinderContainer; 
import pzo.cortex.ICortexInterface;

public class CortexProvider extends ContentProvider {

    public static final String EXTRA_BINDER = "pzo.cortex.extra.BINDER";
    public static final String METHOD_SEND_BINDER = "sendBinder";
    private static final String TAG = "CortexProvider";

    @SuppressLint({"RestrictedApi"})
    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        if (!METHOD_SEND_BINDER.equals(method)) {
            return null;
        }
        if (extras == null) {
            return Bundle.EMPTY;
        }

        // Membuka bungkus parcel binder
        extras.setClassLoader(BinderContainer.class.getClassLoader());
        BinderContainer binderContainer = extras.getParcelable(EXTRA_BINDER);

        if (binderContainer != null) {
            ICortexInterface cortexInterface = binderContainer.binder;
            if (cortexInterface != null) {
                // KIRIM KE ACTIVITY/SERVICE UTAMA APK ANDA
                // Contoh: MainActivity.onBinderReceived(cortexInterface);

                int callingUid = Binder.getCallingUid();
                // Validasi keamanan: Pastikan yang memanggil adalah root/adb atau server kita sendiri
                // (Biasanya uid < 2000 atau sesuai kebutuhan)

                return Bundle.EMPTY;
            }
        }
        return Bundle.EMPTY;
    }

    // --- Override standar ContentProvider (biarkan kosong) ---
    @Override
    public boolean onCreate() { return true; }
    @Override
    public Cursor query(Uri u, String[] p, String s, String[] sa, String o) { return null; }
    @Override
    public String getType(Uri u) { return null; }
    @Override
    public Uri insert(Uri u, ContentValues v) { return null; }
    @Override
    public int delete(Uri u, String s, String[] sa) { return 0; }
    @Override
    public int update(Uri u, ContentValues v, String s, String[] sa) { return 0; }
}

