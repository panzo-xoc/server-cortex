package pzo.cortex.server; // Sesuaikan dengan package Anda

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;

import java.lang.reflect.Method;

// Pastikan file AIDL Anda juga sudah disesuaikan namanya jika diubah
// Misalnya dari IAxeronInterface.aidl menjadi ICortexInterface.aidl
import pzo.cortex.ICortexInterface;

public class CortexService {

    private static final String TAG = "CortexService";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean isRunning = true;

    // 1. Buat wujud asli dari Binder/Remote Control
    private final ICortexInterface.Stub mBinder = new ICortexInterface.Stub() {
        @Override
        public boolean ping() throws RemoteException {
            Log.d(TAG, "Menerima ping dari APK Client");
            return true; // Jika APK memanggil fungsi ini, server akan membalas true
        }

        @Override
        public String execCommand(String command) throws RemoteException {
            Log.d(TAG, "Menerima perintah: " + command);
            // Di sini Anda bisa menaruh logika eksekusi Runtime.getRuntime().exec()
            return "Perintah '" + command + "' diterima oleh server!";
        }
    };

    public static void main(String[] args) {
        // Mencegah system mematikan VM secara sembarangan jika memungkinkan
        try {
            @SuppressLint("PrivateApi")
				Class<?> vmRuntimeClass = Class.forName("dalvik.system.VMRuntime");
            Object runtime = vmRuntimeClass.getMethod("getRuntime").invoke(null);
            vmRuntimeClass.getMethod("setTargetHeapUtilization", float.class).invoke(runtime, 0.75f);
        } catch (Throwable ignored) {}

        // Mengatur nama proses agar mudah dicari di htop/ps (disesuaikan jadi cortex_server)
        try {
            @SuppressLint("PrivateApi")
				Class<?> ddmHandleAppNameClass = Class.forName("android.ddm.DdmHandleAppName");
            ddmHandleAppNameClass.getMethod("setAppName", String.class, int.class).invoke(null, "cortex_server", 0);
        } catch (Throwable ignored) {}

        Looper.prepareMainLooper();

        // Menangkap unhandled exception agar tidak langsung crash (exit 1)
        // [UPDATE] Diganti menggunakan Anonymous Inner Class agar kompatibel dengan AIDE
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
				@Override
				public void uncaughtException(Thread t, Throwable e) {
					Log.e(TAG, "Fatal crash pada thread " + t.getName(), e);
					try {
						Thread.sleep(1000);
					} catch (Throwable ignored) {}
					System.exit(1);
				}
			});

        try {
            new CortexService();
        } catch (Throwable e) {
            Log.e(TAG, "Gagal menginisialisasi CortexService", e);
            System.exit(1);
        }

        // Loop agar server tidak langsung mati setelah berjalan
        Looper.loop();
    }

    public CortexService() {
        Log.i(TAG, "Memulai CortexService...");

        // Safety waiting untuk memastikan system service inti Android sudah menyala
        waitSystemService("package");
        waitSystemService("activity");
        waitSystemService("user");

        try {
            // Serahkan binder kita ke BinderSender agar dikirim ke APK saat terdeteksi
            BinderSender.register(mBinder);
            Log.i(TAG, "BinderSender berhasil didaftarkan.");
        } catch (Throwable e) {
            Log.e(TAG, "Gagal mendaftarkan BinderSender", e);
        }

        // Mulai pemantauan (Watchdog)
        startWatchdog();
    }

    private void startWatchdog() {
        handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					if (!isRunning) return;

					try {
						// Heartbeat: Cek apakah service penting OS masih merespons
						if (getServiceViaReflection("activity") == null) {
							Log.w(TAG, "Activity service sepertinya mati, menunggu kembali...");
							waitSystemService("activity");
						}
					} catch (Throwable e) {
						Log.e(TAG, "Watchdog error", e);
					}

					// Jalankan lagi setiap 10 detik
					handler.postDelayed(this, 10000);
				}
			}, 10000);
    }

    // --- UTILS ---

    private static void waitSystemService(String name) {
        int retryCount = 0;
        while (getServiceViaReflection(name) == null) {
            try {
                Thread.sleep(1000);
                retryCount++;
                // Cegah infinite loop jika OS hang parah
                if (retryCount > 60) {
                    Log.e(TAG, "System service " + name + " timeout setelah 60 detik!");
                    break;
                }
            } catch (Throwable ignored) {}
        }
    }

    // Menggunakan Reflection murni sebagai ganti ServiceManager.getService(name)
    // agar tidak perlu custom android.jar
    private static Object getServiceViaReflection(String name) {
        try {
            @SuppressLint("PrivateApi")
				Class<?> serviceManager = Class.forName("android.os.ServiceManager");
            Method getService = serviceManager.getMethod("getService", String.class);
            return getService.invoke(null, name);
        } catch (Throwable e) {
            return null;
        }
    }
}

