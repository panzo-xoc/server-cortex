# Tentukan arsitektur CPU yang ingin didukung (bisa disesuaikan)
APP_ABI := armeabi-v7a arm64-v8a

# Platform minimal Android API yang didukung (misal: API 21 / Android 5.0)
APP_PLATFORM := android-24

# Menggunakan standard C++ STL (menggantikan cxx dependency)
APP_STL := c++_shared
APP_CPPFLAGS := -std=c++17

# Mode Optimasi (release / debug)
APP_OPTIM := release

