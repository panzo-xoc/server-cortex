LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE := cortexstart

# Daftar file source C++ Anda
LOCAL_SRC_FILES := starter.cpp misc.cpp selinux.cpp cgroup.cpp


LOCAL_CPPFLAGS := -std=c++17 \
                  -Werror=format \
                  -fdata-sections \
                  -ffunction-sections \
                  -fno-exceptions \
                  -fno-rtti \
                  -fno-threadsafe-statics \
                  -fvisibility=hidden \
                  -fvisibility-inlines-hidden

ifeq ($(NDEBUG),1)
    LOCAL_CPPFLAGS += -Os -flto
    LOCAL_LDFLAGS += -flto -Wl,--exclude-libs,ALL -Wl,--gc-sections -Wl,--strip-all
else
    LOCAL_CPPFLAGS += -DDEBUG
endif

# Menghubungkan library sistem log & android API level
LOCAL_LDLIBS := -llog 

include $(BUILD_SHARED_LIBRARY)

